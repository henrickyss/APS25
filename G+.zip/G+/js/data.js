[
    {
        "id": 1,
        "name": "Kit 5 Camisetas Masculinas Básicas Manga Curta",
        "price": 42.49,
        "rating": 4,
        "image": "img/slider-produtos-simples/1-1.webp"
    },
    {
        "id": 2,
        "name": "Nutella pote especial 350G ferrero",
        "price": 19.99,
        "rating": 5,
        "image": "img/slider-produtos-simples/2-1.webp"
    },
    {
        "id": 3,
        "name": "Console Xbox Series S 500gb Ssd",
        "price": 2276.10,
        "rating": 5,
        "image": "img/slider-produtos-simples/3-1.webp"
    },
    {
        "id": 4,
        "name": "Fritadeira Elétrica - Airfryer Ichef Polishop - AllSpace - Exclusive - Preto",
        "price": 899.96,
        "rating": 4,
        "image": "img/slider-produtos-simples/4-1.webp"
    },
    {
        "id": 5,
        "name": "Smart TV 43'' LG 43LM631C0SB.BWZ Full HD Wi-Fi + 2 USB 3 HDMI",
        "price": 1871.10,
        "rating": 4,
        "image": "img/slider-produtos-simples/5-1.webp"
    },
    {
        "id": 6,
        "name": "Tablet Samsung Galaxy A7 Lite 4g 32GB 3GB RAM SM-T225NZAPZTO",
        "price": 1028.99,
        "rating": 4,
        "image": "img/slider-produtos-simples/6-1.webp"
    },
    {
        "id": 7,
        "name": "Kit Máquina de Cortar Cabelos Dual Action Titanium e Multigroom 7 em 1 - Philco",
        "price": 149.99,
        "rating": 3,
        "image": "img/slider-produtos-simples/7-1.webp"
    },
    {
        "id": 8,
        "name": "Sofá 3 Lugares Retrátil e Reclinável Cama inBox Compact 1,80m Velusoft Café",
        "price": 888.99,
        "rating": 4,
        "image": "img/slider-produtos-simples/8-1.webp"
    },
    {
        "id": 9,
        "name": "Cadeira para Auto Snugfix 360º Rotacional Preta Fisher Price - Fisher-Price",
        "price": 975.92,
        "rating": 3,
        "image": "img/slider-produtos-simples/9-1.webp"
    },
    {
        "id": 10,
        "name": "Kit de Ferramentas Fasterr 129 peças Bits e Chaves emergênciais",
        "price": 77.90,
        "rating": 3,
        "image": "img/slider-produtos-simples/10-1.webp"
    }
]